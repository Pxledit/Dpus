Replace cracked .exe with original

Open license manager, Install new certificate, copy this one and press Paste


-----BEGIN GPSOFT PROGRAM CERTIFICATE-----
DGuOAAE0C0DoKJcNAreXVKuImNYqUD2KLmr2gkTmgsicPWp0zLdLyE0DN6Akz
DQ8/SNx/Hv1nJ29hjojmp+2xPsYpnwFsCn7Qbz+CUv88T7RZY9V8efJzcnnm/
D45awRRUE175IzZtIT4vLhAV+X2YCDO/VpEKAGeZ0iJzIMObAqBjyJqjcGuOA
DAEeD4S4yVJ8QaZhk/FajPMTUFLaLBihlwZwIXB2OsBXaZmijlYqnNhUdDgFc
D2W2+aFqNuJ17pDjzK9WTrH8EgXLWlseOzaecRcZCUOLiyNiMfYrVhRHeN9T8
DXldD/aoVw2sPg1ER4o7yQnWtJ9v9QsV4zMujNBLJZZfVTHDtV17iGuOAAEH3
DYYysB18FNu9gthEQes1pf1ELJJl5WLTXGR74yB4g6kBnV1w6Uk+6ddGWVWQt
DJvaewkKgvVewyzVHvQv8r8S8UCSkAwIL7xbgw5y9naHxiK01se7v04X3sTNw
DA3tACh8rNrhOWZJoe9Z+c05ZgrAW07b5+Emgrb5v14kPfd4jGuOAAEspcs41
DlJ1pJMEZDSXcXKbTUR3xne9ufJYkjZ9XGjiKjGjHW6NFedoDAwjOeqr3/K0k
Dc3FDhesg0NovfTNDnnMQQiLC7fqoU0rBreJrEpZQgS8fLJ+ckU8pi6jB1Dx+
DvuTrNa3Ga7CE+5IwinbMom/gmtGMknSTb50qdIkv87zbGuOAAGLmNl8q20m9
DI5Lw8feQ/z5/IOxRTTiTB0BcIh3uZ+svxa3C/fKb+w8Gin+d1gPvBzu2FpL0
DpikpW1YVnPh1v10DFnHHG+FcD5jtw97dc1cNDnBDB3msN5mvGOhlq9XE+0x+
DFoRu9PNzim0IWqv99N1B7YWLGXxD21Ekqy/SfQyn
c0HKEDxBiCOc8b38xt0sd8w==
-----END GPSOFT PROGRAM CERTIFICATE-----


Don't panic.

Even the lic manager tells you that the main program is expired, all functions keep working.

It has been tested for several days.
